package com.toolnest.android.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.toolnest.android.AppBackground
import com.toolnest.android.BackupManager
import com.toolnest.android.LanguageManager
import com.toolnest.android.SettingsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date

/**
 * Backup & Overzetten is opgesplitst in losse pagina's: [Start] toont alleen de keuze tussen
 * maken en terugzetten, zodat [Create] en [Restore] elk het hele scherm hebben. Dat was nodig
 * omdat op één gedeelde pagina maar een paar backups tegelijk zichtbaar waren.
 */
private enum class BackupRestoreScreenMode {
    Start,
    Create,
    Restore,
    RestorePassword
}

@Composable
fun BackupRestoreScreen(
    onBack: () -> Unit,
    initialRestoreUri: Uri? = null
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val textColor = Color(SettingsManager.getTextColor(context))
    val buttonColor = Color(SettingsManager.getButtonColor(context))
    val buttonTextColor = Color(SettingsManager.getButtonTextColor(context))

    var showStoragePermissionDialog by remember { mutableStateOf(false) }

    var backupPassword by remember { mutableStateOf("") }
    var backupPasswordConfirm by remember { mutableStateOf("") }
    var backupInProgress by remember { mutableStateOf(false) }
    var backupError by remember { mutableStateOf<String?>(null) }

    var selectedRestoreUri by remember(initialRestoreUri) { mutableStateOf(initialRestoreUri) }
    var selectedRestoreFilename by remember(initialRestoreUri) {
        mutableStateOf(initialRestoreUri?.let { getDisplayName(context, it) }.orEmpty())
    }
    var restorePassword by remember { mutableStateOf("") }
    var restoreInProgress by remember { mutableStateOf(false) }
    var restoreError by remember { mutableStateOf<String?>(null) }
    var showRestartDialog by remember { mutableStateOf(false) }

    // Backups die op het toestel gevonden zijn, zodat de gebruiker ze niet zelf hoeft op te zoeken.
    var foundBackups by remember { mutableStateOf<List<BackupManager.BackupFileInfo>>(emptyList()) }
    // Welke backup staat op het punt verwijderd te worden (null = geen bevestiging open).
    var pendingDelete by remember { mutableStateOf<BackupManager.BackupFileInfo?>(null) }
    var pendingDeleteAll by remember { mutableStateOf(false) }
    var deleteInProgress by remember { mutableStateOf(false) }

    val refreshBackups: () -> Unit = {
        coroutineScope.launch {
            foundBackups = withContext(Dispatchers.IO) { BackupManager.listBackups(context) }
        }
    }

    // Eén keer bij openen ophalen; na aanmaken/verwijderen wordt dit opnieuw aangeroepen.
    LaunchedEffect(Unit) { refreshBackups() }

    // Wordt de gebruiker rechtstreeks naar een backupbestand gestuurd (bv. vanaf het hoofdscherm),
    // dan slaan we de tussenpagina's over. Het pijltje terug moet dan ook meteen het hele scherm
    // sluiten in plaats van naar een lijst te gaan waar de gebruiker nooit is geweest.
    val openedDirectlyOnFile = initialRestoreUri != null
    var screenMode by remember(initialRestoreUri) {
        mutableStateOf(
            if (openedDirectlyOnFile) BackupRestoreScreenMode.RestorePassword
            else BackupRestoreScreenMode.Start
        )
    }

    val backupPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedRestoreUri = uri
            selectedRestoreFilename = getDisplayName(context, uri)
            restorePassword = ""
            restoreError = null
            screenMode = BackupRestoreScreenMode.RestorePassword
        }
    }

    val runRestore: () -> Unit = {
        val restoreUri = selectedRestoreUri
        when {
            restorePassword.isBlank() -> restoreError = LanguageManager.getString("backup_error_enter_restore_password")
            restoreUri == null -> restoreError = LanguageManager.getString("backup_error_choose_file")
            else -> {
                coroutineScope.launch {
                    restoreInProgress = true
                    restoreError = null
                    val result = BackupManager.restoreBackup(context, restoreUri, restorePassword)
                    restoreInProgress = false
                    result.fold(
                        onSuccess = { showRestartDialog = true },
                        onFailure = { restoreError = localizedBackupFailure(it, "backup_restore_failed") }
                    )
                }
            }
        }
    }

    when (screenMode) {
        BackupRestoreScreenMode.Start -> BackupStartScreen(
            onBack = onBack,
            onCreateBackup = {
                backupPassword = ""
                backupPasswordConfirm = ""
                backupError = null
                screenMode = BackupRestoreScreenMode.Create
            },
            onRestoreBackup = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
                    showStoragePermissionDialog = true
                } else {
                    refreshBackups()
                    screenMode = BackupRestoreScreenMode.Restore
                }
            },
            snackbarHostState = snackbarHostState,
            textColor = textColor,
            buttonColor = buttonColor,
            buttonTextColor = buttonTextColor
        )

        BackupRestoreScreenMode.Create -> CreateBackupScreen(
            onBack = {
                backupError = null
                screenMode = BackupRestoreScreenMode.Start
            },
            backupPassword = backupPassword,
            onBackupPasswordChange = {
                backupPassword = it
                backupError = null
            },
            backupPasswordConfirm = backupPasswordConfirm,
            onBackupPasswordConfirmChange = {
                backupPasswordConfirm = it
                backupError = null
            },
            backupInProgress = backupInProgress,
            backupError = backupError,
            onCreateBackup = {
                when {
                    backupPassword.isBlank() -> backupError = LanguageManager.getString("backup_error_enter_password")
                    backupPassword != backupPasswordConfirm -> backupError = LanguageManager.getString("backup_error_passwords_mismatch")
                    else -> {
                        coroutineScope.launch {
                            backupInProgress = true
                            backupError = null
                            val result = BackupManager.createBackup(context, backupPassword)
                            backupInProgress = false
                            result.fold(
                                onSuccess = { uri ->
                                    backupPassword = ""
                                    backupPasswordConfirm = ""
                                    // Nieuwe backup meteen in het overzicht laten verschijnen.
                                    refreshBackups()
                                    // Terug naar Backup & overzetten. De pagina bleef hiervoor
                                    // staan met lege wachtwoordvelden, alsof je meteen nog een
                                    // backup moest maken - terwijl het klaar was.
                                    screenMode = BackupRestoreScreenMode.Start
                                    snackbarHostState.showSnackbar(localizedBackupCreatedMessage(getDisplayName(context, uri)))
                                },
                                onFailure = { error ->
                                    snackbarHostState.showSnackbar(localizedBackupFailure(error, "backup_create_failed"))
                                }
                            )
                        }
                    }
                }
            },
            snackbarHostState = snackbarHostState,
            textColor = textColor,
            buttonColor = buttonColor,
            buttonTextColor = buttonTextColor
        )

        BackupRestoreScreenMode.Restore -> RestoreListScreen(
            onBack = { screenMode = BackupRestoreScreenMode.Start },
            onPickBackupFile = { backupPickerLauncher.launch(arrayOf("*/*")) },
            foundBackups = foundBackups,
            onSelectBackup = { info ->
                selectedRestoreUri = info.uri
                selectedRestoreFilename = info.filename
                restorePassword = ""
                restoreError = null
                screenMode = BackupRestoreScreenMode.RestorePassword
            },
            onRequestDelete = { info -> pendingDelete = info },
            onRequestDeleteAll = { pendingDeleteAll = true },
            deleteInProgress = deleteInProgress,
            snackbarHostState = snackbarHostState,
            textColor = textColor,
            buttonColor = buttonColor,
            buttonTextColor = buttonTextColor
        )

        BackupRestoreScreenMode.RestorePassword -> RestorePasswordScreen(
            filename = selectedRestoreFilename.ifBlank {
                selectedRestoreUri?.lastPathSegment.orEmpty()
            },
            restorePassword = restorePassword,
            onRestorePasswordChange = {
                restorePassword = it
                restoreError = null
            },
            restoreError = restoreError,
            restoreInProgress = restoreInProgress,
            onBack = {
                if (openedDirectlyOnFile) {
                    onBack()
                } else {
                    restoreError = null
                    screenMode = BackupRestoreScreenMode.Restore
                }
            },
            onRestore = runRestore,
            textColor = textColor,
            buttonColor = buttonColor,
            buttonTextColor = buttonTextColor
        )
    }

    // "Weet je dit zeker?" vóór het verwijderen van één backup.
    pendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { if (!deleteInProgress) pendingDelete = null },
            title = { Text(LanguageManager.getString("backup_delete_confirm_title")) },
            text = {
                Text(
                    String.format(
                        LanguageManager.getLocale(),
                        LanguageManager.getString("backup_delete_confirm_message"),
                        target.filename
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            deleteInProgress = true
                            val result = BackupManager.deleteBackup(context, target.uri)
                            deleteInProgress = false
                            pendingDelete = null
                            if (result.isSuccess) {
                                // Stond deze backup geselecteerd voor herstel? Dan die keuze ook wissen.
                                if (selectedRestoreUri == target.uri) {
                                    selectedRestoreUri = null
                                    selectedRestoreFilename = ""
                                }
                                refreshBackups()
                                snackbarHostState.showSnackbar(LanguageManager.getString("backup_deleted"))
                            } else {
                                snackbarHostState.showSnackbar(LanguageManager.getString("backup_delete_failed"))
                            }
                        }
                    },
                    enabled = !deleteInProgress,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = buttonColor,
                        contentColor = buttonTextColor
                    )
                ) {
                    Text(LanguageManager.getString("backup_delete"))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { pendingDelete = null },
                    enabled = !deleteInProgress
                ) {
                    Text(LanguageManager.getString("backup_cancel"), color = buttonColor)
                }
            }
        )
    }

    // "Weet je dit zeker?" vóór het verwijderen van alle gevonden backups.
    if (pendingDeleteAll) {
        AlertDialog(
            onDismissRequest = { if (!deleteInProgress) pendingDeleteAll = false },
            title = { Text(LanguageManager.getString("backup_delete_confirm_title")) },
            text = {
                Text(
                    String.format(
                        LanguageManager.getLocale(),
                        LanguageManager.getString("backup_delete_all_confirm_message"),
                        foundBackups.size
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            deleteInProgress = true
                            val targets = foundBackups.map { it.uri }
                            val deleted = BackupManager.deleteBackups(context, targets)
                            deleteInProgress = false
                            pendingDeleteAll = false
                            // Stond er een backup geselecteerd voor herstel? Die is nu ook weg.
                            if (targets.any { it == selectedRestoreUri }) {
                                selectedRestoreUri = null
                                selectedRestoreFilename = ""
                            }
                            refreshBackups()
                            if (deleted > 0) {
                                snackbarHostState.showSnackbar(
                                    String.format(
                                        LanguageManager.getLocale(),
                                        LanguageManager.getString("backup_deleted_count"),
                                        deleted
                                    )
                                )
                            } else {
                                snackbarHostState.showSnackbar(LanguageManager.getString("backup_delete_failed"))
                            }
                        }
                    },
                    enabled = !deleteInProgress,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = buttonColor,
                        contentColor = buttonTextColor
                    )
                ) {
                    Text(LanguageManager.getString("backup_delete_all"))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { pendingDeleteAll = false },
                    enabled = !deleteInProgress
                ) {
                    Text(LanguageManager.getString("backup_cancel"), color = buttonColor)
                }
            }
        )
    }

    if (showStoragePermissionDialog) {
        AlertDialog(
            onDismissRequest = { showStoragePermissionDialog = false },
            title = { Text(LanguageManager.getString("backup_storage_permission_title")) },
            text = { Text(LanguageManager.getString("backup_storage_permission_message")) },
            confirmButton = {
                Button(
                    onClick = {
                        showStoragePermissionDialog = false
                        try {
                            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                                data = Uri.parse("package:${context.packageName}")
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            try {
                                context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                            } catch (_: Exception) {}
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = buttonColor,
                        contentColor = buttonTextColor
                    )
                ) {
                    Text(LanguageManager.getString("backup_storage_permission_grant"))
                }
            },
            dismissButton = {
                TextButton(onClick = { showStoragePermissionDialog = false }) {
                    Text(LanguageManager.getString("backup_cancel"), color = buttonColor)
                }
            }
        )
    }

    if (showRestartDialog) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text(LanguageManager.getString("backup_restored_title")) },
            text = { Text(LanguageManager.getString("backup_restored_message")) },
            confirmButton = {
                Button(
                    onClick = { restartApp(context) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = buttonColor,
                        contentColor = buttonTextColor
                    )
                ) {
                    Text(LanguageManager.getString("restart_app"))
                }
            }
        )
    }
}

/**
 * Gedeeld omhulsel voor alle backup-pagina's: achtergrond, veilige marges, het pijltje naar
 * beneden om terug te gaan, en het scrollgedrag.
 *
 * Past de inhoud binnen het scherm, dan staat die verticaal gecentreerd; is de inhoud langer
 * (bv. een lange lijst backups), dan groeit de kolom door en kan er gescrold worden. Dat komt
 * doordat [verticalScroll] de minimumhoogte van [fillMaxSize] doorgeeft: de kolom is dus minstens
 * zo hoog als het scherm, en [Arrangement.spacedBy] met [Alignment.CenterVertically] centreert
 * binnen die hoogte.
 *
 * De scrollstatus gaat ook naar [swipeUpBackGesture], zodat omhoog vegen midden in een lange
 * lijst gewoon scrollt en niet per ongeluk het scherm sluit.
 *
 * [scrollable] uit betekent: deze pagina regelt haar eigen scrollen (een lijst met een eigen
 * [LazyColumn]) en de kolom hier blijft dus precies één schermhoogte, van boven naar beneden
 * gevuld. Dat is nodig voor het backup-overzicht: met een meescrollende buitenkolom liep de
 * lijst achter het terug-pijltje door.
 *
 * [swipeBackEnabled] uit zet de veeg-om-terug-te-gaan uit. Op een pagina die vooral bestaat uit
 * een lange lijst zitten scrollen en "vegen om te sluiten" elkaar in de weg - daar blijft alleen
 * het pijltje onderin over om terug te gaan.
 *
 * [contentBottomPadding] houdt de onderkant van de inhoud vrij van dat pijltje.
 */
@Composable
private fun BackupPageScaffold(
    onBack: () -> Unit,
    snackbarHostState: SnackbarHostState? = null,
    scrollable: Boolean = true,
    swipeBackEnabled: Boolean = true,
    contentBottomPadding: Dp = 96.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val context = LocalContext.current
    val swipeEnabled = SettingsManager.getSwipeEnabled(context) && swipeBackEnabled
    val scrollState = rememberScrollState()

    AppBackground(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .swipeUpBackGesture(
                    enabled = swipeEnabled,
                    scrollState = scrollState,
                    onBack = onBack,
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (scrollable) Modifier.verticalScroll(scrollState) else Modifier)
                    .padding(start = 24.dp, end = 24.dp, top = 24.dp, bottom = contentBottomPadding),
                verticalArrangement = Arrangement.spacedBy(
                    14.dp,
                    if (scrollable) Alignment.CenterVertically else Alignment.Top
                ),
                horizontalAlignment = Alignment.CenterHorizontally,
                content = content
            )

            StandardBackupBackArrow(
                onClick = onBack,
                modifier = Modifier.align(Alignment.BottomCenter)
            )

            snackbarHostState?.let { host ->
                SnackbarHost(
                    hostState = host,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 80.dp)
                )
            }
        }
    }
}

/**
 * Startpagina: alleen de keuze tussen een backup maken of er een terugzetten.
 *
 * Heeft een eigen snackbar-plek omdat het maken van een backup meteen hierheen terugkeert - de
 * "backup gemaakt"-melding hoort dan hier te verschijnen, niet op de pagina die net gesloten is.
 */
@Composable
private fun BackupStartScreen(
    onBack: () -> Unit,
    onCreateBackup: () -> Unit,
    onRestoreBackup: () -> Unit,
    snackbarHostState: SnackbarHostState,
    textColor: Color,
    buttonColor: Color,
    buttonTextColor: Color
) {
    BackupPageScaffold(onBack = onBack, snackbarHostState = snackbarHostState) {
        Text(
            text = LanguageManager.getString("backup_restore"),
            style = MaterialTheme.typography.headlineSmall,
            color = textColor,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = onCreateBackup,
            modifier = Modifier.widthIn(min = 200.dp, max = 280.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = buttonColor,
                contentColor = buttonTextColor
            )
        ) {
            Text(LanguageManager.getString("backup_create"))
        }

        Button(
            onClick = onRestoreBackup,
            modifier = Modifier.widthIn(min = 200.dp, max = 280.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = buttonColor,
                contentColor = buttonTextColor
            )
        ) {
            Text(LanguageManager.getString("backup_restore_action"))
        }
    }
}

/** Pagina om een nieuwe backup te maken: wachtwoord kiezen en bevestigen. */
@Composable
private fun CreateBackupScreen(
    onBack: () -> Unit,
    backupPassword: String,
    onBackupPasswordChange: (String) -> Unit,
    backupPasswordConfirm: String,
    onBackupPasswordConfirmChange: (String) -> Unit,
    backupInProgress: Boolean,
    backupError: String?,
    onCreateBackup: () -> Unit,
    snackbarHostState: SnackbarHostState,
    textColor: Color,
    buttonColor: Color,
    buttonTextColor: Color
) {
    BackupPageScaffold(onBack = onBack, snackbarHostState = snackbarHostState) {
        Text(
            text = LanguageManager.getString("backup_create"),
            style = MaterialTheme.typography.headlineSmall,
            color = textColor,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = backupPassword,
            onValueChange = onBackupPasswordChange,
            label = { Text(LanguageManager.getString("backup_password")) },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        OutlinedTextField(
            value = backupPasswordConfirm,
            onValueChange = onBackupPasswordConfirmChange,
            label = { Text(LanguageManager.getString("backup_confirm_password")) },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        backupError?.let {
            Text(
                text = it,
                color = Color.Red,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        Button(
            onClick = onCreateBackup,
            enabled = !backupInProgress,
            modifier = Modifier.widthIn(min = 180.dp, max = 280.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = buttonColor,
                contentColor = buttonTextColor
            )
        ) {
            Text(
                if (backupInProgress) LanguageManager.getString("backup_create_in_progress")
                else LanguageManager.getString("backup_create")
            )
        }
    }
}

/**
 * Pagina om een backup terug te zetten: het overzicht van alles wat op dit toestel gevonden is,
 * met per regel een verwijderknop.
 *
 * De lijst zelf scrolt ([LazyColumn]), niet de hele pagina. Titel en knoppen blijven daardoor
 * staan, en de lijst houdt op net boven het terug-pijltje in plaats van erachter door te lopen.
 * De veeg-om-terug-te-gaan staat hier uit: op een pagina die uit een lange lijst bestaat, botst
 * die met scrollen. Terug gaat via het pijltje onderin.
 */
@Composable
private fun RestoreListScreen(
    onBack: () -> Unit,
    onPickBackupFile: () -> Unit,
    foundBackups: List<BackupManager.BackupFileInfo>,
    onSelectBackup: (BackupManager.BackupFileInfo) -> Unit,
    onRequestDelete: (BackupManager.BackupFileInfo) -> Unit,
    onRequestDeleteAll: () -> Unit,
    deleteInProgress: Boolean,
    snackbarHostState: SnackbarHostState,
    textColor: Color,
    buttonColor: Color,
    buttonTextColor: Color
) {
    val listState = rememberLazyListState()

    BackupPageScaffold(
        onBack = onBack,
        snackbarHostState = snackbarHostState,
        scrollable = false,
        swipeBackEnabled = false,
        // Iets ruimer dan de andere pagina's: de lijst wordt hier afgekapt op deze grens, en die
        // moet net boven het terug-pijltje liggen in plaats van erachter.
        contentBottomPadding = 112.dp
    ) {
        Text(
            text = LanguageManager.getString("backup_restore_action"),
            style = MaterialTheme.typography.headlineSmall,
            color = textColor,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        if (foundBackups.isEmpty()) {
            // Zonder meescrollende buitenkolom staat de inhoud bovenaan; deze twee spacers
            // centreren de "niets gevonden"-melding weer netjes in het scherm.
            Spacer(Modifier.weight(1f))

            Text(
                text = LanguageManager.getString("backup_none_found"),
                style = MaterialTheme.typography.bodyMedium,
                color = textColor.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = onPickBackupFile,
                modifier = Modifier.widthIn(min = 200.dp, max = 280.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = buttonColor,
                    contentColor = buttonTextColor
                )
            ) {
                Text(LanguageManager.getString("backup_choose_file"))
            }

            Text(
                text = LanguageManager.getString("backup_browse_hint"),
                style = MaterialTheme.typography.bodySmall,
                color = textColor.copy(alpha = 0.5f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.weight(1f))
        } else {
            Text(
                text = LanguageManager.getString("backup_found_title"),
                style = MaterialTheme.typography.titleMedium,
                color = textColor,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            // weight(1f): de lijst krijgt precies de ruimte die overblijft tussen de titel en de
            // knoppen eronder, en scrollt binnen die ruimte. Hoeveel backups er ook staan, de
            // knoppen blijven zichtbaar en er loopt niets achter het pijltje langs.
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Sleutel op de URI, niet op de bestandsnaam: die is uniek, ook als er ooit twee
                // bestanden met dezelfde naam uit verschillende bronnen langskomen.
                items(foundBackups, key = { it.uri.toString() }) { info ->
                    BackupListRow(
                        info = info,
                        enabled = !deleteInProgress,
                        onSelect = { onSelectBackup(info) },
                        onDelete = { onRequestDelete(info) },
                        textColor = textColor,
                        buttonColor = buttonColor
                    )
                }
            }

            if (foundBackups.size > 1) {
                Button(
                    onClick = onRequestDeleteAll,
                    enabled = !deleteInProgress,
                    modifier = Modifier.widthIn(min = 180.dp, max = 280.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = buttonColor,
                        contentColor = buttonTextColor
                    )
                ) {
                    Text(LanguageManager.getString("backup_delete_all"))
                }
            }

            Button(
                onClick = onPickBackupFile,
                modifier = Modifier.widthIn(min = 180.dp, max = 280.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = buttonColor,
                    contentColor = buttonTextColor
                )
            ) {
                Text(LanguageManager.getString("backup_choose_file"))
            }
        }
    }
}

/**
 * Eén regel in het backup-overzicht: tik op de regel om deze backup terug te zetten, of op het
 * prullenbakje om 'm te verwijderen. Bewust zonder scheidingslijn tussen de regels.
 */
@Composable
private fun BackupListRow(
    info: BackupManager.BackupFileInfo,
    enabled: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit,
    textColor: Color,
    buttonColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onSelect)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = info.filename,
                style = MaterialTheme.typography.bodyMedium,
                color = textColor,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${formatBackupTimestamp(info.lastModifiedMs)} · ${formatBackupSize(info.sizeBytes)}",
                style = MaterialTheme.typography.bodySmall,
                color = textColor.copy(alpha = 0.7f)
            )
        }
        IconButton(
            onClick = onDelete,
            enabled = enabled
        ) {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = LanguageManager.getString("backup_delete"),
                tint = buttonColor
            )
        }
    }
}

/** Datum en tijd van de backup in de taal/regio van de gebruiker, bv. "25 jul 2026 12:31". */
private fun formatBackupTimestamp(millis: Long): String {
    if (millis <= 0L) return ""
    return SimpleDateFormat("d MMM yyyy HH:mm", LanguageManager.getLocale()).format(Date(millis))
}

/** Bestandsgrootte kort en leesbaar; onder de 1 kB tonen we gewoon bytes. */
private fun formatBackupSize(bytes: Long): String {
    if (bytes <= 0L) return ""
    val locale = LanguageManager.getLocale()
    return when {
        bytes >= 1024L * 1024L -> String.format(locale, "%.1f MB", bytes / (1024.0 * 1024.0))
        bytes >= 1024L -> String.format(locale, "%.0f kB", bytes / 1024.0)
        else -> String.format(locale, "%d B", bytes)
    }
}

/** Wachtwoordpagina voor de gekozen backup. */
@Composable
private fun RestorePasswordScreen(
    filename: String,
    restorePassword: String,
    onRestorePasswordChange: (String) -> Unit,
    restoreError: String?,
    restoreInProgress: Boolean,
    onBack: () -> Unit,
    onRestore: () -> Unit,
    textColor: Color,
    buttonColor: Color,
    buttonTextColor: Color
) {
    BackupPageScaffold(onBack = onBack) {
        Text(
            text = LanguageManager.getString("backup_restore_action"),
            style = MaterialTheme.typography.headlineSmall,
            color = textColor,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Text(
            text = LanguageManager.getString("backup_selected"),
            style = MaterialTheme.typography.titleMedium,
            color = textColor,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Text(
            text = filename,
            style = MaterialTheme.typography.bodyLarge,
            color = textColor,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = restorePassword,
            onValueChange = onRestorePasswordChange,
            label = { Text(LanguageManager.getString("backup_password")) },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        restoreError?.let { error ->
            Text(
                text = error,
                color = Color.Red,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (restoreInProgress) {
            Text(
                text = LanguageManager.getString("backup_restore_in_progress"),
                color = textColor,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        Button(
            onClick = {
                if (!restoreInProgress) onRestore()
            },
            enabled = !restoreInProgress,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = buttonColor,
                contentColor = buttonTextColor
            )
        ) {
            Text(
                if (restoreInProgress) LanguageManager.getString("backup_restore_in_progress")
                else LanguageManager.getString("backup_restore_button")
            )
        }
    }
}

@Composable
private fun StandardBackupBackArrow(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    SwipeIndicators(
        modifier = modifier,
        isVertical = true,
        showDown = true,
        onSwipeDown = onClick
    )
}

private fun localizedBackupCreatedMessage(filename: String): String {
    return String.format(
        LanguageManager.getLocale(),
        LanguageManager.getString("backup_created_format"),
        filename
    )
}

private fun localizedBackupFailure(error: Throwable, fallbackKey: String): String {
    val key = when (error.message) {
        "Wachtwoord mag niet leeg zijn" -> "backup_error_password_empty"
        "Kan backupbestand niet openen" -> "backup_error_file_open_failed"
        "Verkeerd wachtwoord" -> "backup_error_wrong_password"
        else -> fallbackKey
    }
    return LanguageManager.getString(key)
}

private fun getDisplayName(context: Context, uri: Uri): String {
    runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
    }.getOrNull()?.use { cursor ->
        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (nameIndex >= 0 && cursor.moveToFirst()) {
            return cursor.getString(nameIndex).orEmpty()
        }
    }
    return uri.lastPathSegment.orEmpty()
}

private fun restartApp(context: Context) {
    val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
    }
    if (launchIntent != null) {
        context.startActivity(launchIntent)
    }
    (context as? Activity)?.finish()
}
