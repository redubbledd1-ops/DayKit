﻿package com.toolnest.android

import com.toolnest.android.util.CountdownFormatter
import com.toolnest.android.util.CountdownMode

/**
 * Tray/status compact time — delegates to [CountdownFormatter] (timer, stopwatch notifications).
 */
object TimerDisplayFormat {

    fun formatMillisCompact(millis: Long): String =
        CountdownFormatter.format(millis, CountdownMode.COMPACT_TRAY)
}
