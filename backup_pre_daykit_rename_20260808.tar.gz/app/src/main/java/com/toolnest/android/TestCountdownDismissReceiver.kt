﻿package com.toolnest.android

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * POC only: [Notification.deleteIntent] — logs swipe-dismiss; does not stop the service or alarm.
 */
class TestCountdownDismissReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        Log.i(TestCountdownForegroundService.TAG, "NOTIFICATION_SWIPE_DISMISS — tray cleared; alarm/timer logic keeps running in service")
        TestCountdownForegroundService.onNotificationSwipeDismissed()
        TestCountdownForegroundService.requestSwipeTeardown(context)
    }
}
