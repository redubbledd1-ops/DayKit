﻿package com.toolnest.android

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * POC backup: exact alarm at countdown end so alarm still fires if process/service stops after swipe-dismiss.
 */
class TestCountdownAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        Log.i(TestCountdownForegroundService.TAG, "BACKUP_ALARM_RECEIVER fired wallClock=${System.currentTimeMillis()}")
        TestCountdownForegroundService.onBackupAlarmElapsed(context.applicationContext)
    }
}
