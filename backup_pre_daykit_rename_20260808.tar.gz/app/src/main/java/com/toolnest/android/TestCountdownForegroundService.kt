﻿package com.toolnest.android

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/**
 * POC countdown foreground service.
 * Primary rendering = custom compact RemoteViews (the nicer look),
 * with system fallback if a device rejects custom rendering.
 */
class TestCountdownForegroundService : Service() {

    private val serviceJob = SupervisorJob()
    private val scope = CoroutineScope(serviceJob + Dispatchers.Default)
    private var tickerJob: Job? = null

    @Volatile
    private var endAtEpochMs: Long = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "SERVICE_ON_CREATE")
        PopupNotificationFoundation.ensureTimerChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                Log.i(TAG, "ACTION_STOP_PRESS")
                clearPersistedSession(this)
                cancelBackupAlarm(this)
                shutdownEverything(removeNotification = true, reason = "stop_action")
                return START_NOT_STICKY
            }
            ACTION_SWIPE_TEARDOWN -> {
                Log.i(TAG, "SWIPE_DISMISS_TEARDOWN")
                suppressNotificationUi.set(true)
                try {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } catch (e: Exception) {
                    Log.w(TAG, "stopForeground after swipe failed", e)
                }
                return START_STICKY
            }
            ACTION_CLEANUP_SILENT -> {
                Log.i(TAG, "CLEANUP_SILENT")
                tickerJob?.cancel()
                tickerJob = null
                clearPersistedSession(this)
                val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                nm.cancel(NOTIFICATION_ID)
                try {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                } catch (_: Exception) {
                }
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                resetSwipeSuppressState()
                synchronized(TestCountdownForegroundService::class.java) {
                    persistSessionStart(
                        this,
                        intent.getLongExtra(EXTRA_END_AT_MS, System.currentTimeMillis() + DURATION_MS)
                    )
                }
                val now = System.currentTimeMillis()
                endAtEpochMs = getPrefs(this).getLong(KEY_END_AT, now + DURATION_MS)
                logBatteryHint()
                logThemeColorsResolved()

                scheduleBackupAlarm(this, endAtEpochMs)
                Log.i(TAG, "SERVICE_START_TEST endAtEpochMs=$endAtEpochMs")

                tickerJob?.cancel()
                val initial = buildNotification(remainingMs(endAtEpochMs), "initial_startForeground")
                startForegroundWithType(initial)

                tickerJob = scope.launch {
                    while (isActive) {
                        val remaining = remainingMs(endAtEpochMs)
                        if (remaining <= 0L) {
                            cancelBackupAlarm(this@TestCountdownForegroundService)
                            val claimed = tryMarkDeliveredPersistence(this@TestCountdownForegroundService)
                            if (claimed) {
                                fireAlarm()
                                Log.i(TAG, "ALARM_FIRED_TICKER wallClock=${System.currentTimeMillis()}")
                            } else {
                                Log.i(TAG, "ALARM_SKIP_TICKER already_delivered_by_backup")
                            }
                            shutdownEverything(removeNotification = true, reason = "alarm_complete")
                            break
                        }

                        Log.d(
                            TAG,
                            "NOTIFICATION_UPDATE_TICK remainingMs=$remaining (${formatMmSs(remaining)}) suppressedUi=${suppressNotificationUi.get()}"
                        )

                        if (!suppressNotificationUi.get()) {
                            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                            nm.notify(
                                NOTIFICATION_ID,
                                buildNotification(remaining, "ticker_${remaining / 1000L}s")
                            )
                        }

                        delay(TICK_MS)
                    }
                }
                return START_STICKY
            }
            else -> {
                Log.w(TAG, "Unknown action ${intent?.action}, ignoring")
                return START_NOT_STICKY
            }
        }
    }

    override fun onDestroy() {
        Log.i(TAG, "SERVICE_ON_DESTROY")
        tickerJob?.cancel()
        serviceJob.cancel()
        super.onDestroy()
    }

    private fun remainingMs(endAt: Long): Long = (endAt - System.currentTimeMillis()).coerceAtLeast(0L)

    private fun fireAlarm() {
        fireAlarmVibrate(this)
    }

    private fun shutdownEverything(removeNotification: Boolean, reason: String) {
        Log.i(TAG, "SERVICE_SHUTDOWN reason=$reason removeNotification=$removeNotification")
        tickerJob?.cancel()
        tickerJob = null
        if (removeNotification) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(NOTIFICATION_ID)
        }
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {
        }
        stopSelf()
    }

    private fun startForegroundWithType(notification: android.app.Notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SHORT_SERVICE)
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            @Suppress("DEPRECATION")
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_NONE)
        } else {
            @Suppress("DEPRECATION")
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun logThemeColorsResolved() {
        val text = SettingsManager.getTextColor(this)
        val button = SettingsManager.getButtonColor(this)
        val buttonText = SettingsManager.getButtonTextColor(this)
        val appBackground = SettingsManager.getBackgroundColor(this)
        val bgType = SettingsManager.getBackgroundType(this)
        val gifUri = SettingsManager.getBackgroundGifUri(this).orEmpty()
        Log.i(
            TAG,
            "THEME_COLORS_RESOLVED text=${hex(text)} button=${hex(button)} buttonText=${hex(buttonText)} appBg=${hex(appBackground)} bgType=$bgType gifSet=${gifUri.isNotBlank()}"
        )
    }

    private fun resolveNotificationBackgroundColor(): Int {
        val backgroundType = SettingsManager.getBackgroundType(this).lowercase()
        val gifUri = SettingsManager.getBackgroundGifUri(this).orEmpty()
        val useBlackFallback = backgroundType.contains("gif") || gifUri.isNotBlank()
        val resolved = if (useBlackFallback) Color.BLACK else SettingsManager.getBackgroundColor(this)
        Log.i(TAG, "BACKGROUND_COLOR_RESOLVE gif_fallback_black=$useBlackFallback resolved=${hex(resolved)}")
        return resolved
    }

    private fun buildNotification(remainingMs: Long, rebuildTag: String): android.app.Notification {
        val titleColor = SettingsManager.getTextColor(this)
        val subtitleColor = SettingsManager.getTextColor(this)
        val stopButtonColor = SettingsManager.getButtonColor(this)
        val stopGlyphColor = SettingsManager.getButtonTextColor(this)
        val backgroundColor = resolveNotificationBackgroundColor()
        val mmSs = formatMmSs(remainingMs)

        Log.i(TAG, "NOTIFICATION_REBUILD tag=$rebuildTag mmSs=$mmSs render=custom_compact bg=${hex(backgroundColor)}")

        val stopPi = buildStopPendingIntent()
        val contentPi = buildContentPendingIntent()
        val deletePi = buildDeletePendingIntent()

        return runCatching {
            val compactRv = RemoteViews(packageName, R.layout.notification_poc_compact).apply {
                applyThemedRemoteViews(this, mmSs, titleColor, subtitleColor, stopButtonColor, stopGlyphColor, backgroundColor)
                setOnClickPendingIntent(R.id.poc_stop_click, stopPi)
            }

            PopupNotificationFoundation.pocCompactStyleBuilder(this, CHANNEL_ID, backgroundColor)
                .setCustomContentView(compactRv)
                .setContentIntent(contentPi)
                .setDeleteIntent(deletePi)
                .build()
        }.getOrElse { err ->
            Log.w(TAG, "CUSTOM_RENDER_FAILED fallback=system_compact reason=${err.javaClass.simpleName}")
            PopupNotificationFoundation.pocCompactStyleBuilder(this, CHANNEL_ID, backgroundColor)
                .setContentTitle(mmSs)
                .setContentText(getString(R.string.poc_notification_subtitle))
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPi)
                .setContentIntent(contentPi)
                .setDeleteIntent(deletePi)
                .build()
        }
    }

    private fun buildStopPendingIntent(): PendingIntent {
        val stopIntent = Intent(this, TestCountdownForegroundService::class.java).apply {
            action = ACTION_STOP
        }
        return PendingIntent.getService(
            this,
            REQ_CODE_STOP,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildDeletePendingIntent(): PendingIntent {
        val deleteIntent = Intent(this, TestCountdownDismissReceiver::class.java)
        return PendingIntent.getBroadcast(
            this,
            REQ_CODE_DELETE,
            deleteIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildContentPendingIntent(): PendingIntent {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_OPEN_AGENDA_ALARM, true)
        }
        return PendingIntent.getActivity(
            this,
            REQ_CODE_CONTENT_TAP,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun applyThemedRemoteViews(
        rv: RemoteViews,
        mmSs: String,
        titleColor: Int,
        subtitleColor: Int,
        stopButtonColor: Int,
        stopGlyphColor: Int,
        backgroundColor: Int
    ) {
        rv.setInt(R.id.poc_root, "setBackgroundColor", backgroundColor)
        rv.setTextViewText(R.id.notification_countdown, getString(R.string.poc_notification_title, mmSs))
        rv.setTextViewText(R.id.poc_subtitle, getString(R.string.poc_notification_subtitle))
        rv.setTextColor(R.id.notification_countdown, titleColor)
        rv.setTextColor(R.id.poc_subtitle, subtitleColor)
        rv.setInt(R.id.poc_stop_circle, "setColorFilter", stopButtonColor)
        rv.setTextColor(R.id.poc_stop_glyph, stopGlyphColor)
    }

    private fun formatMmSs(remainingMs: Long): String {
        val totalSec = (remainingMs.coerceAtLeast(0L)) / 1000L
        val m = totalSec / 60L
        val s = totalSec % 60L
        return String.format("%02d:%02d", m, s)
    }

    private fun logBatteryHint() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val ignoring = pm.isIgnoringBatteryOptimizations(packageName)
            Log.i(TAG, "BATTERY_OPTIMIZATION ignored=$ignoring")
        } catch (e: Exception) {
            Log.w(TAG, "BATTERY_OPTIMIZATION check failed", e)
        }
    }

    private fun hex(c: Int): String = String.format("#%08X", c)

    companion object {
        const val TAG = "TestCountdownPoc"

        const val NOTIFICATION_ID = 9001
        private const val CHANNEL_ID = PopupNotificationFoundation.TIMER_CHANNEL_ID

        const val ACTION_START = "com.toolnest.android.poc.TEST_COUNTDOWN_START"
        const val ACTION_STOP = "com.toolnest.android.poc.TEST_COUNTDOWN_STOP"
        private const val ACTION_SWIPE_TEARDOWN = "com.toolnest.android.poc.TEST_SWIPE_TEARDOWN"
        private const val ACTION_CLEANUP_SILENT = "com.toolnest.android.poc.TEST_CLEANUP_SILENT"

        private const val EXTRA_END_AT_MS = "end_at_ms"
        private const val DURATION_MS = 60_000L
        private const val TICK_MS = 1000L

        private const val REQ_CODE_STOP = 4401
        private const val REQ_CODE_DELETE = 4402
        private const val REQ_CODE_CONTENT_TAP = 4403
        private const val REQ_ALARM_BACKUP = 4410

        private const val POC_PREFS = "poc_test_countdown_prefs"
        private const val KEY_ACTIVE = "active"
        private const val KEY_END_AT = "end_at_epoch_ms"
        private const val KEY_DELIVERED = "delivered"

        private val suppressNotificationUi = AtomicBoolean(false)

        fun resetSwipeSuppressState() {
            suppressNotificationUi.set(false)
        }

        fun onNotificationSwipeDismissed() {
            suppressNotificationUi.set(true)
            Log.i(TAG, "NOTIFICATION_SWIPE_DISMISS")
        }

        fun startOneMinuteTest(context: Context) {
            val app = context.applicationContext
            val endAt = System.currentTimeMillis() + DURATION_MS
            Log.i(TAG, "startOneMinuteTest scheduled endAtEpochMs=$endAt")
            val i = Intent(app, TestCountdownForegroundService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_END_AT_MS, endAt)
            }
            ContextCompat.startForegroundService(app, i)
        }

        private fun getPrefs(context: Context) =
            context.applicationContext.getSharedPreferences(POC_PREFS, Context.MODE_PRIVATE)

        private fun persistSessionStart(context: Context, endAt: Long) {
            getPrefs(context).edit()
                .putBoolean(KEY_ACTIVE, true)
                .putLong(KEY_END_AT, endAt)
                .putBoolean(KEY_DELIVERED, false)
                .apply()
        }

        private fun clearPersistedSession(context: Context) {
            getPrefs(context).edit().clear().apply()
        }

        private fun scheduleBackupAlarm(context: Context, endAt: Long) {
            val app = context.applicationContext
            val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(app, TestCountdownAlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                app,
                REQ_ALARM_BACKUP,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (am.canScheduleExactAlarms()) {
                        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAt, pi)
                    } else {
                        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAt, pi)
                    }
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAt, pi)
                }
            } catch (e: Exception) {
                Log.e(TAG, "BACKUP_ALARM_SCHEDULE failed", e)
            }
        }

        private fun cancelBackupAlarm(context: Context) {
            val app = context.applicationContext
            val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(app, TestCountdownAlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(
                app,
                REQ_ALARM_BACKUP,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.cancel(pi)
            pi.cancel()
        }

        private fun tryMarkDeliveredPersistence(context: Context): Boolean {
            val prefs = getPrefs(context)
            synchronized(TestCountdownForegroundService::class.java) {
                if (prefs.getBoolean(KEY_DELIVERED, false)) return false
                prefs.edit().putBoolean(KEY_DELIVERED, true).putBoolean(KEY_ACTIVE, false).apply()
                return true
            }
        }

        fun onBackupAlarmElapsed(context: Context) {
            val prefs = getPrefs(context)
            if (!prefs.getBoolean(KEY_ACTIVE, false)) return
            val endAt = prefs.getLong(KEY_END_AT, 0L)
            val now = System.currentTimeMillis()
            if (now + 750 < endAt) return
            if (prefs.getBoolean(KEY_DELIVERED, false)) return

            prefs.edit().putBoolean(KEY_DELIVERED, true).putBoolean(KEY_ACTIVE, false).apply()
            Log.i(TAG, "ALARM_FIRED_BACKUP_ALARM_MANAGER wallClock=$now")
            fireAlarmVibrate(context.applicationContext)
            context.applicationContext.startService(
                Intent(context.applicationContext, TestCountdownForegroundService::class.java).apply {
                    action = ACTION_CLEANUP_SILENT
                }
            )
        }

        private fun fireAlarmVibrate(context: Context) {
            try {
                val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    vm.defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0L, 400L, 120L, 400L), -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(longArrayOf(0L, 400L, 120L, 400L), -1)
                }
            } catch (e: Exception) {
                Log.e(TAG, "ALARM vibrate failed", e)
            }
        }

        internal fun requestSwipeTeardown(context: Context) {
            context.applicationContext.startService(
                Intent(context.applicationContext, TestCountdownForegroundService::class.java).apply {
                    action = ACTION_SWIPE_TEARDOWN
                }
            )
        }
    }
}
